1. I occasionally asked my friend Tyler Braun for help.
2. Some of my challenges include figuring out where to put the line of code to pop the current element.
	I figured this out through trial and error.
3. I liked how this assignment was something you could slowly figure out and get excited about.
	I didn't like the instructed method for the stack method because in my opinion,
	you shouldn't pop the current element; you should only pop the incorrect elements.
4. I spend about 8 hours working on this assignment.