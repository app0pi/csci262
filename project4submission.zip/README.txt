Note: CPW gave me an extension on this project.

1. Tyler Braun answered some questions I had regarding the project.
2. Some challenges I faced were reading in the file, so I just used the C++ reference guide.
3. I liked how there wasn't a lot of places for bugs.
4. I spent 2 days on the project.
5. I added a feature that deletes the binary search tree one node at a time by postorder traversal at the end in order to avoid memory leaks.