Name: Kenny Lieu
Lab Partner: Tyler Braun